package HMS;

import java.time.LocalDate;

public class Appointment {
    public enum Status {SCHEDULED, COMPLETED, CANCELED}

    public String getDoctorName() {
		return doctorName;
	}

	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	private String doctorName;
    private String patientName;
    private LocalDate date;
    private String comments;
    private Status status;

    public Appointment(String doctorName, String patientName, LocalDate date) {
        this.doctorName = doctorName;
        this.patientName = patientName;
        this.date = date;
        this.status = Status.SCHEDULED;
    }

}
