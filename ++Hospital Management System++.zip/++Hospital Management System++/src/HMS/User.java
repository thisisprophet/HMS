package HMS;

public class User {
    public enum Role {ADMIN, PATIENT, DOCTOR}

    private String name;
    private int age;
    private String gender;
    private Role role;
    private String specialization;

    public User(String name, Role role) {
        this.setName(name);
        this.setRole(role);
    }

    public User(String name, int age, String gender) {
        this.setName(name);
        this.setAge(age);
        this.setGender(gender);
        this.setRole(Role.PATIENT);
    }

    public User(String name, String specialization) {
        this.setName(name);
        this.setSpecialization(specialization);
        this.setRole(Role.DOCTOR);
    }

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public String getSpecialization() {
		return specialization;
	}

	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}

    
}
