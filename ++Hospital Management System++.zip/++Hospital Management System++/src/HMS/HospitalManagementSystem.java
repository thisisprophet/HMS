package HMS;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;



public class HospitalManagementSystem {
    private List<User> users;
    private List<Appointment> appointments;
    private User activeUser;

    public HospitalManagementSystem() {
        users = new ArrayList<>();
        appointments = new ArrayList<>();
        users.add(new User("admin", User.Role.ADMIN));
    }

    public void signIn(String name) throws UserNotFoundException {
        for (User user : users) {
            if (user.getName().equals(name)) {
                activeUser = user;
                System.out.println(user.getRole() + " " + user.getName() + " signed in successfully");
                return;
            }
        }
        throw new UserNotFoundException("User not found");
    }

    public void signOut() {
        if (activeUser != null) {
            System.out.println(activeUser.getRole() + " " + activeUser.getName() + " signed out");
            activeUser = null;
        }
    }

    public void registerDoctor(String doctorName, String specialization) {
        if (activeUser != null && activeUser.getRole() == User.Role.ADMIN) {
            users.add(new User(doctorName, specialization));
            System.out.println("Doctor registered successfully");
        } else {
            System.out.println("Only admin can register doctors");
        }
    }

    public void registerPatient(String name, int age, String gender) {
        users.add(new User(name, age, gender));
        System.out.println("Patient registered successfully");
    }

    public void listOfDoctors() {
        for (User user : users) {
            if (user.getRole() == User.Role.DOCTOR) {
                System.out.println(user.getName() + " " + user.getSpecialization());
            }
        }
    }

    public void bookAppointment(String doctorName, LocalDate date) {
        if (activeUser != null && activeUser.getRole() == User.Role.PATIENT) {
            Appointment appointment = new Appointment(doctorName, activeUser.getName(), date);
            appointments.add(appointment);
            System.out.println("Appointment with " + doctorName + " for " + date + " is successful");
        } else {
            System.out.println("Only patients can book appointments");
        }
    }

    public void viewAppointments(String name) {
        for (Appointment appointment : appointments) {
            if (appointment.getDoctorName().equals(name) || appointment.getPatientName().equals(name)) {
                System.out.println(appointment.getDoctorName() + " " + appointment.getPatientName() + " " + appointment.getDate() + " " + appointment.getComments());
            }
        }
    }

    public void rescheduleAppointment(String doctorName, LocalDate oldDate, LocalDate newDate) {
        if (activeUser != null && activeUser.getRole() == User.Role.PATIENT) {
            for (Appointment appointment : appointments) {
                if (appointment.getDoctorName().equals(doctorName) && appointment.getPatientName().equals(activeUser.getName()) && appointment.getDate().equals(oldDate)) {
                    appointment.setDate(newDate);
                    System.out.println("Appointment rescheduled successfully");
                    return;
                }
            }
            System.out.println("Appointment not found");
        } else {
            System.out.println("Only patients can reschedule appointments");
        }
    }

    public void cancelAppointment(String name, LocalDate date) throws AppointmentNotFoundException {
        if (activeUser != null && (activeUser.getRole() == User.Role.PATIENT || activeUser.getRole() == User.Role.DOCTOR)) {
            Appointment appointmentToRemove = null;
            for (Appointment appointment : appointments) {
                if (appointment.getDoctorName().equals(name) && appointment.getDate().equals(date) || appointment.getPatientName().equals(name) && appointment.getDate().equals(date)) {
                    appointmentToRemove = appointment;
                    break;
                }
            }

            if (appointmentToRemove != null) {
                appointments.remove(appointmentToRemove);
                System.out.println("Appointment canceled");
            } else {
                throw new AppointmentNotFoundException("Appointment not found");
            }
        } else {
            System.out.println("Only patients and doctors can cancel appointments");
        }
    }

    public void visitUpdate(String patientName, LocalDate date, String comments) {
        if (activeUser != null && activeUser.getRole() == User.Role.DOCTOR) {
            for (Appointment appointment : appointments) {
                if (appointment.getPatientName().equals(patientName) && appointment.getDoctorName().equals(activeUser.getName()) && appointment.getDate().equals(date)) {
                    appointment.setComments(comments);
                    System.out.println("Visit Details Updated");
                    return;
                }
            }
            System.out.println("Appointment not found");
        } else {
            System.out.println("Only doctors can update visit details");
        }
        
    }

    public static void main(String[] args) {
        HospitalManagementSystem hms = new HospitalManagementSystem();

        
        try {
            hms.signIn("admin");
            hms.registerDoctor("Jim", "Cardiology");
            hms.registerDoctor("Sneha", "Ophthalmology");
            hms.signOut();

            hms.registerPatient("John", 24, "Male");
            hms.signIn("John");
            hms.listOfDoctors();
            hms.bookAppointment("Jim", LocalDate.of(2023, 4, 12));
            hms.viewAppointments("Jim");
            hms.rescheduleAppointment("Jim", LocalDate.of(2023, 4, 12), LocalDate.of(2023, 4, 16));
            hms.cancelAppointment("Jim", LocalDate.of(2023, 4, 16));
            hms.signOut();

            hms.signIn("Jim");
            hms.viewAppointments("John");
            hms.visitUpdate("John", LocalDate.of(2023, 4, 12), "Completely recovered");
            hms.cancelAppointment("John", LocalDate.of(2023, 4, 16));
            hms.signOut();
        } catch (UserNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (AppointmentNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }
}
